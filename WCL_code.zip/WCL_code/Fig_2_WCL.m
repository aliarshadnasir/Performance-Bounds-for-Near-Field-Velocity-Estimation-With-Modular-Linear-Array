%% Generate figure 2

close all;
clear all;  
c = 3e8;    % speed of light
addpath("functions")

%% systems parameter 
f = 28e9;                % carrier frequency
N = 200;
n = 1:N;
B = 100e3;
Ts = 1/B;
lambda = c/f;            % wavelength
dx = lambda/2;           % antenna spacing

L = 61;
K = 2;
tot_ant = 240;        % total number of antennas
M = round(tot_ant/K); % number of antennas per subarrat
U = M + L - 1;

% aperture length
A = dx*( K*(M-1)+L*(K-1) );      % Array length

d_F_mod = sqrt(A.^3/(4*lambda)); % Fresnel distance for the modular array

% target parameters
r  = 1*d_F_mod;
th1 = pi/2;
th2 = pi/4;

%% Gain reduction due velocity mismatch

vr_max = 30; 
vt_max = 30;

% Grid
delta_vr=(-vr_max:1:vr_max); len_vr=length(delta_vr); 
delta_vt=(-vt_max:1:vt_max); len_vt=length(delta_vt); 

array_gain_mod1_vr  = zeros(1,len_vr);
array_gain_mod2_vr  = zeros(1,len_vr);

array_gain_mod1_vt = zeros(1,len_vt);
array_gain_mod2_vt = zeros(1,len_vt);

mag_mod1_vt = zeros(1,len_vt);
mag_mod2_vt = zeros(1,len_vt);

% mismatch in radial velocity 
for i=1:len_vr
    
    % modular ULA
    a_gt_mod1 = velocity_vector_mod(r,th1,M,dx,lambda,0,0,Ts,n,K,L);
    a_es_mod1 = velocity_vector_mod(r,th1,M,dx,lambda,delta_vr(i),0,Ts,n,K,L);
    array_gain_mod1_vr(i) = min(abs(diag(a_es_mod1'*a_gt_mod1)));

    % Same modular array, evaluated at theta=pi/4
    a_gt = velocity_vector_mod(r,th2,M,dx,lambda,0,0,Ts,n,K,L);
    a_es = velocity_vector_mod(r,th2,M,dx,lambda,delta_vr(i),0,Ts,n,K,L);
    array_gain_mod2_vr(i) = min(abs(diag(a_es'*a_gt)));
    
end

% mismatch in transverse velocity
for i=1:len_vt

    a_gt_mod1 = velocity_vector_mod(r,th1,M,dx,lambda,0,0,Ts,n,K,L);
    a_es_mod1 = velocity_vector_mod(r,th1,M,dx,lambda,0,delta_vt(i),Ts,n,K,L);

    a_gt_mod2 = velocity_vector_mod(r,th2,M,dx,lambda,0,0,Ts,n,K,L);
    a_es_mod2 = velocity_vector_mod(r,th2,M,dx,lambda,0,delta_vt(i),Ts,n,K,L);

    array_gain_mod1_vt(i) = min(abs(diag(a_es_mod1'*a_gt_mod1)));
    array_gain_mod2_vt(i) = min(abs(diag(a_es_mod2'*a_gt_mod2)));
    
    phi1    = 2*pi*delta_vt(i)*dx*Ts*sin(th1).*n./(r*lambda);
    sinc_M1 = dirich_sinc(phi1,M);
    sinc_K1 = dirich_sinc(phi1.*U,K);
    
    phi2    = 2*pi*delta_vt(i)*dx*Ts*sin(th2).*n./(r*lambda);
    sinc_M2 = dirich_sinc(phi2,M);
    sinc_K2 = dirich_sinc(phi2.*U,K);

    % the function ψ(n) 
    mag_mod1_vt(i) = min(abs(sinc_M1.*sinc_K1));
    mag_mod2_vt(i) = min(abs(sinc_M2.*sinc_K2));
end

%% Plot parameters
lgnd_fontsize  = 6;
label_fontsize = 8;
lin_width = 1.2;

RGB = orderedcolors("gem");  % N×3 matrix
thirdRGB = RGB(3,:);         % 1x3 RGB triplet for the third color

%%

figure

set(gcf,'Units','centimeters')
set(gcf,'Position',[0 0 8.8 7]);   % [left bottom width height] in cm

subplot(211)
plot(delta_vr,array_gain_mod1_vr,LineWidth=lin_width); hold on; grid on;   % theta = pi/2
plot(delta_vr,array_gain_mod2_vr,LineWidth=lin_width,Color=RGB(3,:));      % theta = pi/4
xlabel('$\Delta v_r$ [$m/s$]',Interpreter='latex',FontSize=label_fontsize)
ylabel('min $|\psi(n)|^2$','Interpreter','latex',FontSize=label_fontsize)
ylim([239 240])

legend('\theta = \pi/2: Exact (7)','\theta = \pi/4: Exact (7)',Fontsize=lgnd_fontsize,Location='best')

subplot(212)
plot(delta_vt,array_gain_mod1_vt,LineWidth=lin_width); hold on;
plot(delta_vt,mag_mod1_vt,LineWidth=lin_width,LineStyle="--",Marker="diamond",...
        MarkerIndices=1:20:length(delta_vt)); grid on;

plot(delta_vt,array_gain_mod2_vt,LineWidth=lin_width,Color=thirdRGB);
plot(delta_vt,mag_mod2_vt,LineWidth=lin_width,LineStyle="--",Marker="square",...
        MarkerIndices=1:20:length(delta_vt));
xlabel('$\Delta v_t$ [$m/s$]',Interpreter='latex',FontSize=label_fontsize)
ylabel('min $|\psi(n)|^2$','Interpreter','latex',FontSize=label_fontsize)

legend(['\theta = \pi/2: Exact (7)'],['\theta = \pi/2: Approximation (9)'],...
       ['\theta = \pi/4: Exact (7)'],['\theta = \pi/4: Approximation (9)'],...
       Fontsize=lgnd_fontsize,Location='best')
%
% Common settings
set(gcf,'Renderer','painters');                % vector output
set(groot,'defaultAxesFontName','Times');      % or 'Helvetica'
set(groot,'defaultTextFontName','Times');
set(groot,'defaultAxesFontSize',9);

% set(gcf,'Color','none');   % optional: transparent figure background
% print(gcf, 'Fig_2', '-depsc2', '-vector');
