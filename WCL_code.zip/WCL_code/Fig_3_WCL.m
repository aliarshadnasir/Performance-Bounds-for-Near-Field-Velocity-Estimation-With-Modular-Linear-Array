%% بسم الله الرحمن الرحيم
%% Generate figure 3

clear all;
close all; clc; 
format long
addpath("functions")

%%
results = load('MSE_1000.mat'); % loading the results

mse_vr_mla = results.mse_vr_mla;
mse_vt_mla = results.mse_vt_mla;

mse_vr_ula = results.mse_vr_ula;
mse_vt_ula = results.mse_vt_ula;

gamma = results.gamma;

r = results.r;
len_r = results.len_r;
th = results.th;        % direction (rad)

d_F = results.d_F;
%% system parameter

tot_ant = results.tot_ant;

M_ula = results.M_ula;
K_ula = results.K_ula;
L_ula = results.L_ula;

M_mla = results.M_mla;
K_mla = results.K_mla;
L_mla = results.L_mla;

dx = results.dx;
%% Plot parameters

lin_width      = results.lin_width;
lgnd_fontsize  = results.lgnd_fontsize;
label_fontsize = results.label_fontsize;

RGB = results.RGB;

final = results.final;
%%  crb_modular(r,th,M1,dx,Ch.Gain,K1,L1);
[crb_vr_mod_1,crb_vt_mod_1] = crb_velocity_mla(r,th,M_ula,dx,gamma./r.^4,K_ula,L_ula);
[crb_vr_mod_2,crb_vt_mod_2] = crb_velocity_mla(r,th,M_mla,dx,gamma./r.^4,K_mla,L_mla);

%%
figure
set(gcf,'Units','centimeters')
set(gcf,"Position",[0 0 8.8 7])

subplot(211)
semilogy(r,mse_vr_ula,LineWidth=lin_width,Color=RGB(5,:),Marker="o",MarkerIndices=(1:3:len_r));hold on;
semilogy(r,mse_vr_mla,LineWidth=lin_width,Color='k')
semilogy(r,crb_vr_mod_1,LineWidth=lin_width,...
         LineStyle='--',Color=RGB(1,:),Marker="x",MarkerIndices=(2:3:len_r)); grid on;

semilogy(r,crb_vr_mod_2,LineWidth=lin_width,LineStyle="--",Marker='square',MarkerIndices=(3:3:len_r),Color=RGB(2,:));
xline(d_F,'--k')
xlabel('Distance [$m$]',FontSize=label_fontsize,Interpreter='latex')
ylabel('Radial MSE/CRB',Interpreter='latex',FontSize=label_fontsize);
xlim([0.5*d_F final])
yticks(10.^(-6:0))                    % [1e-7 1e-6 1e-5 1e-4 1e-3]


legend(['MSE$_{ULA}$: Ref [1]'],...
       ['MSE$_{MLA}$: Ref [1]'],...
       ['CRB$^{(v_r)}_{ULA}$ (16)'],...
       ['CRB$^{(v_r)}_{MLA}$ (14)' ],...
        'Interpreter','latex',Location='best',FontSize=lgnd_fontsize)

subplot(212)
semilogy(r,mse_vt_ula,LineWidth=lin_width,Color=RGB(5,:),Marker="o",MarkerIndices=(1:3:len_r)); hold on;
semilogy(r,mse_vt_mla,LineWidth=lin_width,Color='k')
semilogy(r,crb_vt_mod_1,LineWidth=lin_width,...
         LineStyle='--',Color=RGB(1,:),Marker="x",MarkerIndices=(2:3:len_r)); grid on;
semilogy(r,crb_vt_mod_2,LineWidth=lin_width,LineStyle='--',Marker='square',MarkerIndices=(3:3:len_r),Color=RGB(2,:));
xline(d_F,'--k')

xlabel('Distance [$m$]',FontSize=label_fontsize,Interpreter='latex')
ylabel('Transverse MSE/CRB',Interpreter='latex',FontSize=label_fontsize);
xlim([0.5*d_F final])
yticks(10.^(-5:0))                    % [1e-7 1e-6 1e-5 1e-4 1e-3]


legend(['MSE$_{ULA}$: Ref [1]'],...
       ['MSE$_{MLA}$: Ref [1]'],...
       ['CRB$^{(v_r)}_{ULA}$ (17)'],...
       ['CRB$^{(v_r)}_{MLA}$ (15)' ],...
        'Interpreter','latex',Location='best',FontSize=lgnd_fontsize)
