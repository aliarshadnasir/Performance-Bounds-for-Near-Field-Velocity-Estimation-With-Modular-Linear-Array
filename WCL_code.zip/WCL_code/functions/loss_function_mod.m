function [obj, grad] = loss_function_mod(Y,sig_n, r, theta, eta, M, N, dx, lambda, Ts,K,L)

%Loss function and gradient for maximum likelihood estimation
%   loss_function(Y, r, theta, eta, M, N, A, d, lambda, Ts, s)
% Inputs:
%   Y:      signal received over one CPI
%   r:      distance of the target
%   theta:  direction of the target
%   eta:    vector of velocities
%   M:      antennas per module; total number is M*K
%   N:      length of one CPI
%   dx:     antenna spacing (m) at the BS
%   lambda: signal wavelength
%   Ts:     symbol period
%   sig:    transmit signal
% Outputs:
%   obj:    loss function
%   grad:   gradient

%Date: 03/06/2024
%Author: Zhaolin Wang
%Modified by: Khalid Alshumayri on Saturday 23/8/2025 

vr = eta(1); vt = eta(2);
%% Define the index of the modular array
U = M+L-1;
% m and k vectors
m = -(M-1)/2 : (M-1)/2;
k = -(K-1)/2 : (K-1)/2;

% Make 2D grids: each (m,k) pair
[Kgrid, Mgrid] = meshgrid(k, m);

% Compute etx for all pairs
etx = (U .* Kgrid + Mgrid) .* dx;
etx = etx(:);

% Compute r_mk as column vector
r_mk = sqrt(r.^2 + etx.^2 - 2 .* r .* etx .* cos(theta));
X = match_filter_mod(sig_n,r, theta, vr, vt, M, N, dx, lambda, Ts,K,L);

% objective function (minimize)
obj = -abs(trace(X'*Y))^2/real(trace(X*X'));   

if nargout > 1 % gradient required
    n = 1:N;
    [d_n] = velocity_vector_mod(r, theta, M, dx, lambda, vr, vt, Ts,n,K,L);
    qmk = (r - etx*cos(theta))./r_mk;
    pmk = etx*sin(theta)./r_mk;
    
    d_vr = -1i*2*pi/lambda*Ts*qmk.*n .* d_n;
    d_vt = -1i*2*pi/lambda*Ts*pmk.*n .* d_n;
    a = array_response_mod(r, theta, M, dx, lambda,K,L);
    
    H = a.*d_n;
    H_vr = a.*d_vr;
    H_vt = a.*d_vt;
    
    X_vr = zeros(M*K, N); 
    X_vt = zeros(M*K, N);

    % Product rule for H_n=h_n*h_n.'; both TX and RX depend on velocity.
    for j = 1:N
        hn = H(:,j);
        hn_vr = H_vr(:,j);
        hn_vt = H_vt(:,j);
        X_vr(:,j) = ( hn_vr*hn.' + hn*hn_vr.' ) * sig_n(:,j);
        X_vt(:,j) = ( hn_vt*hn.' + hn*hn_vt.' ) * sig_n(:,j);
    end
     
    X_norm = norm(X,"fro")^2;
    Theta = trace(Y*X')*X_norm;
    Omega = abs(trace(Y*X'))^2;
    g_X = (Theta*Y' - Omega*X')/X_norm^2;
    
    grad = zeros(2,1);
    grad(1) = -2*real(trace(g_X*X_vr));
    grad(2) = -2*real(trace(g_X*X_vt));
end

end
