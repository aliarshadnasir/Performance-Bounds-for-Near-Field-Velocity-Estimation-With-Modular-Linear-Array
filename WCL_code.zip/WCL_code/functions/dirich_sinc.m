function f = dirich_sinc(phi,M)
    % Dirichlet sinc function
    % phi : scalar, vector, or matrix
    % M   : scalar

    f = sin(phi.*M./2)./sin(phi./2);   % general case
    f(phi == 0) = M;                  % fix values where phi == 0
    % f = f./M;

end
