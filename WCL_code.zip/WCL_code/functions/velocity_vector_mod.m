function [d_n,v_mk] = velocity_vector_mod(r, theta, M, dx, lambda, vr, vt, Ts,n,K,L)

%   calculating the near-field doppler-frequency vector at time index n
%   [d, v_m] = velocity_vector(r, theta, M, d, lambda, vr, vt, Ts, n) 
%   during single CPI
% Inputs:
%   r: distance of the target
%   theta: direction of the target
%   M: antennas per module; total number is M*K
%   dx: antenna spacing at the BS
%   lambda: signal wavelength
%   vr: radial velocity of the target
%   vt: transverse velocity of the target
%   Ts: symbol period
%   n: time index
%   K: number of modules
%   L: nearest-element inter-module gap in units of dx

% Outputs:
%   d:      doppler-frequenct vector
%   v_mk:   velocity vector at all antennas

% Date: 03/06/2024
% Author: Zhaolin Wang
% Modified by: Khalid Alshumayri 

r = r(:)';
U = M+L-1;

% m and k vectors
m = -(M-1)/2 : (M-1)/2;
k = -(K-1)/2 : (K-1)/2;

% Make 2D grids: each (m,k) pair
[Kgrid, Mgrid] = meshgrid(k, m);

% Compute etx for all pairs
etx = (U .* Kgrid + Mgrid) .* dx;
etx = etx(:);

theta = reshape(theta, 1, 1, []); % theta is a 1x1xK array

% Compute r_mk as column vector
r_mk = sqrt(r.^2 + etx.^2 - 2 .* r .* etx .* cos(theta));

% Eq. (2): project radial/transverse velocity onto each antenna-target line.
q_mk = (r - etx*cos(theta))./r_mk;
p_mk = etx*sin(theta)./r_mk;

vr_mk = q_mk * vr;
vt_mk = p_mk * vt;

v_mk = vr_mk + vt_mk;

% Doppler frequency vector
d_n = exp( -1i * 2 * pi /lambda * v_mk*n*Ts );
end
