function [crb_vr, crb_vt] = crb_velocity_mla(r,theta,M,dx,gamma,K,L)

% Approximate modular-array CRBs, paper Eqs. (14)-(15).
% Written by Khalid Feb. 2025
% r and dx are in metres; theta is in radians; CRB units are (m/s)^2.
% gamma is Eq. (10), including r^-4 when pathloss is required.
% Vector inputs are paired and should have equal length (or be scalars).
% The formulas are approximate and assume identifiable velocities; endfire
% is degenerate. The radial denominator must remain positive.
%%
% Normalize scalar/vector inputs to columns; no fixed length is assumed.
theta = theta(:); 
gamma = gamma(:);
r = r(:);

% eps=delta/r is a column because r was already made a column.
eps = dx./r;
U   = M + L - 1;
G = M*K*( (K^2-1)*U^2 + M^2-1 )/12;

crb_vr = 1./(gamma.*M*K.*(M*K - eps.^2.*G));
crb_vt = 1./(gamma*M*K.*G.*eps.^2.*sin(theta).^2);
