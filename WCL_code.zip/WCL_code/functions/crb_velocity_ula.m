function [crb_vr, crb_vt] = crb_velocity_ula(r,theta,M,dx,gamma)

% Approximate ULA CRBs, paper Eqs. (16)-(17).
% Written by Khalid Feb. 2025

% r and dx are in metres; 
% theta is in radians; 
% CRB units are (m/s)^2.
% gamma is Eq. (10), including r^-4 when pathloss is required.

%% Ensure theta is a column vector
theta = theta(:); 
gamma = gamma(:);
r = r(:);

% eps=delta/r is a column because r was already made a column.
eps = dx./r;

%% expression

crb_vr = 12./( gamma*M.^2.*(12 - eps.^2.*(M^2-1)) );
crb_vt = 12./(gamma.*M.^2.*(M^2-1).*eps.^2.*(sin(theta)).^2);
