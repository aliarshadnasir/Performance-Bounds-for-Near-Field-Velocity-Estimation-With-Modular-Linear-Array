function [SqEr_vr,SqEr_vt,vr_est,vt_est] = simulate_velocity_mle(r,theta,vr,vt,M,lambda,B,N,SNR,v0,K,L) 

% Estimating the radial and transverse velocities based on maximum
% likelihood estimation and quasi-Newton method

%% system parameter

dx = lambda/2;      % antenna spacing (m)
Ts = 1/B;           % symbol duration (s)

%% signal model

% constant-modulus symbols
data = sign(randn(1,N));
Z = 1/sqrt(2) * (randn(M*K,N) + 1i * randn(M*K,N));  % Noise

% Beamformer uses the true velocities: an oracle-matched single-CPI setup.
% sig_n is subsequently held fixed while the MLE varies candidate velocity.
% beamformer
a       = array_response_mod(r, theta, M, dx, lambda, K, L);                 
[d_n,~] = velocity_vector_mod(r, theta, M, dx, lambda, ... 
                              vr, vt, Ts,1:N,K,L); % 1-array maximization      

W = diag(conj(a))*conj(d_n);                       % 2-Doppler compensation
W = sqrt(SNR)*W./vecnorm(W);                       % MK x N 

% --- transmit signal 
sig_n = W .* data;                                 % matrix: (M*K) x N     

%% Match Filter 

[X] = match_filter_mod(sig_n,r, theta, vr, vt,...
                         M, N, dx, lambda, Ts, K, L);

%%

% RCS magnitude is already included in SNR. Normalizing the complex draw
% gives unit magnitude and random phase, not Gaussian-magnitude fading.
% --- Reflection phase 
beta = randn(1) + 1i*randn(1);      
beta = beta ./ abs(beta);
Y = beta*X + Z;

%% MLE estimation
% --- fminunc options must match what loss_function returns ---
options = optimoptions('fminunc', ...
    'Algorithm','quasi-newton', ...
    'SpecifyObjectiveGradient',true, ...
    'Display','off');

% fminunc seeks a local minimum starting at v0; it is not a global guarantee.
[v] = fminunc(@(eta)(...
    loss_function_mod(Y,sig_n, r, theta, eta, M, N, dx, lambda, Ts,K,L)...
                     ),v0,options);

vr_est = v(1);
vt_est = v(2);

% calculate the squared error 
SqEr_vr = (vr_est-vr)^2;    
SqEr_vt = (vt_est-vt)^2;
