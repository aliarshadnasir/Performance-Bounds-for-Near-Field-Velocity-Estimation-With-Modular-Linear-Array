function [X] = match_filter_mod(sig_n,r, theta, vr, vt, M, N, dx, lambda, Ts,K,L)

% Noise-free echo template for a candidate location and velocity.
% Despite its historical name, this function constructs X, not a data filter.
%   [X] = match_filter(r, theta, vr, vt, M, N, A, d, lambda, Ts, s)
% Inputs:
%   r: distance of the target
%   theta: direction of the target
%   vr: radial velocity of the target
%   vt: transverse velocity of the target
%   M: number of antennas at the BS
%   N: length of one CPI
%   dx: antenna spacing (m) at the BS
%   lambda: signal wavelength
%   T_s: symbol period
%   sig: transmit signal conj(a)*symbols/norm(a)
% Outputs:
%   X: matched filter
% Date: 03/06/2024
% Author: Zhaolin Wang
% Modified by: Khalid Alshumayri on Saturday 23/8/2025

X = zeros(M*K,N);

d_n_mod = velocity_vector_mod(r, theta, M, dx, lambda, vr, vt, Ts,1:N,K,L);
a = array_response_mod(r, theta, M, dx, lambda,K,L);
H = a .* d_n_mod;

for i = 1:N      
    h_n    = H(:,i);
    H_n    = h_n*h_n.';% Nonconjugate transpose is intentional (monostatic echo).
    X(:,i) = H_n*sig_n(:,i);
end
