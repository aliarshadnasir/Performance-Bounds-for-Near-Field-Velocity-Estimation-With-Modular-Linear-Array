function [a] = array_response_mod(r, theta, M, dx, lambda,K,L)

%   near-field array response vector
%   [a] = array_response(r, theta, M, d, lambda)

% Inputs:
%   r:      distance of the target
%   theta:  direction of the target
%   M:      number of antennas per module
%   dx:     antenna spacing 
%   lambda: signal wavelength
%   K:      number of modules
%   L:      nearest-element inter-module gap in units of dx

% Output:
%   a: array response vector

%Date: 03/06/2024
%Author: Zhaolin Wang
%Modified by: Khalid Alshumayri

% array response vector
U = M+L-1;

% m and k vectors
m = -(M-1)/2 : (M-1)/2;
k = -(K-1)/2 : (K-1)/2;

% Make 2D grids: each (m,k) pair
[Kgrid, Mgrid] = meshgrid(k, m);

% Compute etx for all pairs
etx = (U .* Kgrid + Mgrid) .* dx;
etx = etx(:);

theta = reshape(theta, 1, 1, []); % theta is a 1x1xK array

% Compute r_mk as column vector
r_mk = sqrt(r.^2 + etx.^2 - 2 .* r .* etx .* cos(theta));

% Output: array response vector
a = exp( -1i * 2 * pi /lambda * r_mk )./r_mk;

end