
%% بسم الله الرحمن الرحيم
% Written by Khalid A. Alshumayri 

close all; clc; clear;
format long

% Generates new Monte Carlo results in the workspace and plots MSE vs CRB.
% Saving is still manual: the original save command below remains commented.
% Requires Optimization Toolbox and Parallel Computing Toolbox.

iterations = 1000; % <---- number of realizations
%% target parameter

vr = 10;     % radial velocity (m/s)
vt = 8;      % transverse velocity (m/s)
v0 = [11;7]; % initilization
%% system parameter

tot_ant = 240;  % total number of antenna

K_ula = 1;       % number of modules
M_ula = tot_ant; % number of antenna per module
L_ula = 1;       % separation between modules

K_mla = 2;
M_mla = round(tot_ant/K_mla);
L_mla = 1 + 60;
%%

Tc     = 2e-3;      % coherence time of one CPI (s);
c      = 3e8;        % speed of light (m/s)
f      = 28e9;       % carrier frequency (Hz)
lambda = c/f;   % signal wavelength (m)

dx  = lambda/2;  % antenna spacing (m)
A   = ( L_mla*(K_mla-1)+K_mla*(M_mla-1) )*dx;
d_F = sqrt(A^3/lambda)/2; % Fresnel distance

B  = 100e3;        % system bandwidth (Hz)
Ts = 1/B;          % symbol duration (s)
N  = floor(Tc/Ts); % coherence period interval
%% SNR

RCS   = 10^(-2.3);     % -23 dBsm, converted to square metres
Pt_dB = -10;           % transmit power (dBm)
Pt    = 10^(Pt_dB/10); % transmit power (mW)
N0    = 10^(-174/10)*B;% noise power (mW)

% SNR = RCS*Pt*lambda^2/(N0*(4*pi)^3)./r.^4; % with pathloss
SNR = RCS*Pt*lambda^2/(N0*(4*pi)^3); % without pathloss

%%

start   = 0.2*d_F;
final   = 3.1*d_F;      % in meters
incr    = 0.4*d_F;
r     = start:incr:final;
r     = r(:);
len_r = length(r);
th    = pi*90/180; % direction (rad)

% The first two ranges are below d_F; the paper approximation is intended
% for r >= d_F. The original grid is retained.

%% Gain

% gamma omits r^-4 here; the CRB calls below apply that factor once.
sum_n2_Ts = N*(N+1)*(2*N+1)*Ts^2/6; 
zeta      = 2*pi/lambda;
gamma     = 2*SNR*sum_n2_Ts*zeta.^2;

%%
mse_vr_realiz_ula = zeros(iterations,len_r);
mse_vt_realiz_ula = zeros(iterations,len_r);
mse_vr_realiz_mla = zeros(iterations,len_r);
mse_vt_realiz_mla = zeros(iterations,len_r);

vr_est_ula   = zeros(iterations,len_r);
vt_est_ula   = zeros(iterations,len_r);

%% ===== Setup =====
numIterations = iterations * len_r;   % total iterations

% Each update corresponds to one range/trial pair (both arrays simulated).
% Create DataQueue
q = parallel.pool.DataQueue;

% Create progress tracker object (closure keeps state)
progressFcn = makeProgressBar(numIterations);

% Register callback
afterEach(q, progressFcn);

tic
% ====== Main Loop ======
% Keep the original loop and random-number behavior.
parfor u = 1:iterations
    for k = 1:len_r

        [mse_vr_realiz_ula(u,k), mse_vt_realiz_ula(u,k), ...
         vr_est_ula(u,k), vt_est_ula(u,k)] = ...
         simulate_velocity_mle(r(k), th, vr, vt, ...
                                      M_ula  , lambda, B, N, ...
                                      SNR , v0, K_ula, L_ula);

        [mse_vr_realiz_mla(u,k), mse_vt_realiz_mla(u,k), ...
         vr_est_mla(u,k), vt_est_mla(u,k)] = ...
         simulate_velocity_mle(r(k), th, vr, vt, ...
                                      M_mla  , lambda, B, N, ...
                                      SNR , v0, K_mla, L_mla);

        % send update after each iteration
        send(q, 1);
    end
end
ExecutionTime = toc   % stop timer, store elapsed time

%% Plot parameters
lgnd_fontsize  = 6;
label_fontsize = 8;
lin_width = 1.2;

RGB = orderedcolors("gem");   % N×3 matrix
%%
mse_vr_ula = mean(mse_vr_realiz_ula,1);
mse_vt_ula = mean(mse_vt_realiz_ula,1);
mse_vr_mla = mean(mse_vr_realiz_mla,1);
mse_vt_mla = mean(mse_vt_realiz_mla,1);

%%  crb_modular(r,th,M1,dx,Gain,K1,L1);
[crb_vr_mod_1,crb_vt_mod_1] = crb_modular(r,th,M_ula,dx,gamma./r.^4,K_ula,L_ula);
[crb_vr_mod_2,crb_vt_mod_2] = crb_modular(r,th,M_mla,dx,gamma./r.^4,K_mla,L_mla);
% The K_ula=1 modular call above already gives the same ULA bounds.

%%
figure
set(gcf,'Units','centimeters')
set(gcf,"Position",[0 0 8.8 7])

subplot(211)
semilogy(r,mse_vr_ula,LineWidth=lin_width,Color=RGB(5,:),Marker="o",MarkerIndices=(1:3:len_r));hold on;
semilogy(r,mse_vr_mla,LineWidth=lin_width,Color='k')
semilogy(r,crb_vr_mod_1,LineWidth=lin_width,...
         LineStyle='--',Color=RGB(1,:),Marker="x",MarkerIndices=(2:3:len_r)); grid on;

semilogy(r,crb_vr_mod_2,LineWidth=lin_width,LineStyle="--",Marker='square',MarkerIndices=(3:3:len_r),Color=RGB(2,:));
xline(d_F,'--k')
xlabel('Distance [$m$]',FontSize=label_fontsize,Interpreter='latex')
ylabel('Radial MSE/CRB',Interpreter='latex',FontSize=label_fontsize);
xlim([0.5*d_F final])
yticks(10.^(-6:0))                    % [1e-7 1e-6 1e-5 1e-4 1e-3]

legend(['MSE$_{ULA}$: Ref [1]'],...
       ['MSE$_{MLA}$: Ref [1]'],...
       ['CRB$^{(v_r)}_{ULA}$ (16)'],...
       ['CRB$^{(v_r)}_{MLA}$ (14)' ],...
        'Interpreter','latex',Location='best',FontSize=lgnd_fontsize)

subplot(212)
semilogy(r,mse_vt_ula,LineWidth=lin_width,Color=RGB(5,:),Marker="o",MarkerIndices=(1:3:len_r)); hold on;
semilogy(r,mse_vt_mla,LineWidth=lin_width,Color='k')
semilogy(r,crb_vt_mod_1,LineWidth=lin_width,...
         LineStyle='--',Color=RGB(1,:),Marker="x",MarkerIndices=(2:3:len_r)); grid on;
semilogy(r,crb_vt_mod_2,LineWidth=lin_width,LineStyle='--',Marker='square',MarkerIndices=(3:3:len_r),Color=RGB(2,:));
xline(d_F,'--k')

xlabel('Distance [$m$]',FontSize=label_fontsize,Interpreter='latex')
ylabel('Transverse MSE/CRB',Interpreter='latex',FontSize=label_fontsize);
xlim([0.5*d_F final])
yticks(10.^(-5:0))                    % [1e-7 1e-6 1e-5 1e-4 1e-3]

legend(['MSE$_{ULA}$: Ref [1]'],...
       ['MSE$_{MLA}$: Ref [1]'],...
       ['CRB$^{(v_t)}_{ULA}$ (17)'],...
       ['CRB$^{(v_t)}_{MLA}$ (15)' ],...
        'Interpreter','latex',Location='best',FontSize=lgnd_fontsize)

print(gcf, 'MSE', '-depsc2', '-vector');
%%
% Optional: uncomment to save the workspace after this simulation.
% Use a new filename to avoid overwriting your supplied MSE_1000.mat.
% save('MSE_10_Dec_2025_init_vr10_vt4.mat')

% vr_est_neg_value = sum(sum(vr_est_ula<0))
% vt_est_neg_value = sum(sum(vt_est_ula<0))

%% ===== Helper Function =====
function fcn = makeProgressBar(total)
    count = 0; % private state
    fcn = @update;
    function update(~)
        count = count + 1;
        if mod(count, 10) == 0 || count == total
            fprintf('Progress: %d / %d (%.2f%%)\n', ...
                    count, total, 100*count/total);
        end
    end
end
