%% Generate figure 4
clear all; close all; clc;
addpath("functions")

%% System parameters

N = 200;
f = 28e9;
c = 3e8;
lambda = c/f;
B  = 100e3;
Ts = 1/B;
dx = lambda/2;
th = 90*pi/180;

%% Array parameters
tot_ant = 240;
a = 0.2;

% 1
L1 = 61;
M1 = 120;
K1 = 2; 

% 
K2 = K1;
M2 = 99;
% M2 = round(99*2/K2);
L2 = L1;

% 
M3 = M2;
K3 = K1;
L3 = L1 + K3*(M1-M3);   % same aperture as #1 (K=2)


u1 = M1 + L1 - 1;
u2 = M2 + L2 - 1; 
u3 = M3 + L3 - 1;

A_single  = (tot_ant-1)*dx;
A1        = (L1*(K1-1)+K1*(M1-1))*dx;
A2        = (L2*(K2-1)+K2*(M2-1))*dx;
A3        = (L3*(K3-1)+K3*(M3-1))*dx;
%% Plot parameters
lgnd_fontsize  = 6;
label_fontsize = 8;
lin_width = 1.2;

%% Fresnel distance and Range 
d_F_array     = sqrt(A1^3/lambda)/2;       % Array Fresnel distance
d_R_array     = 2*A1^2/lambda;             % Rayleigh distance of the array

d_F_subarray1 = sqrt((dx*(M1-1))^3/lambda)/2; % subarray Fresnel distance 
d_F_subarray2 = sqrt((dx*(M2-1))^3/lambda)/2; 
d_F_subarray3 = sqrt((dx*(M3-1))^3/lambda)/2; 

d_R_subarray1 = 2*(dx*(M1-1))^2/lambda;       % subarray Rayleigh distance 
d_R_subarray2 = 2*(dx*(M2-1))^2/lambda;
d_R_subarray3 = 2*(dx*(M3-1))^2/lambda;

d_F_single    = sqrt( (dx*(tot_ant-1))^3/lambda )/2;

% range
Start = d_F_array;
Final = 3*Start;
incr  = 0.1*Start;
r     = Start:incr:Final;
len_r = length(r);
%% SNR
RCS   = 10^(-2.3);
Pt_dB = -10;           % transmit power (dB)
Pt    = 10^(Pt_dB/10);    % transmit power (mW)
N0    = 10^(-174/10)*B;   % noise power (mW)

% SNR = RCS*Pt*lambda^2/(N0*(4*pi)^3)./r.^4; % with pathloss
SNR = RCS*Pt*lambda^2/(N0*(4*pi)^3); % without pathloss

%% Gain
sum_n2_Ts = N*(N+1)*(2*N+1)*Ts^2/6; 
zeta      = 2*pi/lambda;
gamma     = 2*SNR*sum_n2_Ts*zeta.^2;

%% Calling CRB  
[crb_vr,crb_vt]           = crb_velocity_ula(r,th,tot_ant,dx,gamma);
[crb_vr_mod1,crb_vt_mod1] = crb_velocity_mla(r,th,M1,dx,gamma,K1,L1);
[crb_vr_mod2,crb_vt_mod2] = crb_velocity_mla(r,th,M2,dx,gamma,K2,L2);
[crb_vr_mod3,crb_vt_mod3] = crb_velocity_mla(r,th,M3,dx,gamma,K3,L3);

%%
figure
set(gcf,'Units','centimeters')
set(gcf,"Position",[0 0 8.8 7.5])

subplot(211)
semilogy(r,crb_vr,LineWidth=lin_width,Marker="x",...
         MarkerIndices=(1:4:len_r)); hold on;

semilogy(r,crb_vr_mod1,LineWidth=lin_width,Marker='square',...
         MarkerIndices=(3:4:len_r)); grid on;

semilogy(r,crb_vr_mod2,LineWidth=lin_width,Marker="diamond",...
         MarkerIndices=(3:4:len_r));

semilogy(r,crb_vr_mod3,LineWidth=lin_width,Marker="hexagram",...
         MarkerIndices=(1:4:len_r),LineStyle="--");

xline(d_F_array,'--k')

xlabel('Distance [$m$]',Interpreter='latex',FontSize=label_fontsize)
ylabel('CRB($v_r$)',Interpreter='latex',FontSize=label_fontsize);

legend(['ULA: $M_{0}$ = ',num2str(tot_ant)]...
      ,['$M$ = ',num2str(M1),', $K$ = ',num2str(K1),', $L$ = ',num2str(L1)]...
      ,['$\bar{M}$ = ',num2str(M2),', $K$ = ',num2str(K2),', $\bar{L}$ = ',num2str(L2)]...
      ,['$M$ = ',num2str(M3),', $K$ = ',num2str(K3),', $L$ = ', num2str(L3)]...
      ,'Interpreter','latex',Fontsize=lgnd_fontsize,Location='best')
box off

subplot(212)
semilogy(r,crb_vt,LineWidth=lin_width,Marker="x",...
         MarkerIndices=(1:4:len_r)); hold on;

semilogy(r,crb_vt_mod1,LineWidth=lin_width,Marker='square',...
    MarkerIndices=(3:4:len_r)); grid on;

semilogy(r,crb_vt_mod2,LineWidth=lin_width,Marker="diamond",...
         MarkerIndices=(3:4:len_r));

semilogy(r,crb_vt_mod3,LineWidth=lin_width,Marker="hexagram",...
         MarkerIndices=(1:4:len_r),LineStyle="--");

xline(d_F_array,'--k');

xlabel('Distance [$m$]',Interpreter='latex',FontSize=label_fontsize)
ylabel('CRB($v_t$)',Interpreter='latex',FontSize=label_fontsize);

legend(['ULA: $M_{0}$ = ',num2str(tot_ant)]...
      ,['$M$ = ',num2str(M1),', $K$ = ',num2str(K1),', $L$ = ',num2str(L1)]...
      ,['$\bar{M}$ = ',num2str(M2),', $K$ = ',num2str(K2),', $\bar{L}$ = ',num2str(L2)]...
      ,['$M$ = ',num2str(M3),', $K$ = ',num2str(K3),', $L$ = ', num2str(L3)]...
      ,'Interpreter','latex',Fontsize=lgnd_fontsize,Location='southeast')

box off
% set(gcf,'Color','none');   % optional: transparent figure background
% print(gcf, 'Fig_4', '-depsc2', '-vector');
